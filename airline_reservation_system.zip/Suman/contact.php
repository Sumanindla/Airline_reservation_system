<?php
include 'core/init.php';
include 'includes/overall/header.php';?>
<?php
if(isset($_POST)){
if (empty($_POST) === false) {
	
	
	$name		= $_POST['name'];
	$email		= $_POST['email'];
	$text	= $_POST['text'];

	mysql_query("INSERT INTO feedback (name, email, message) VALUES ('$name', '$email', '$text')");
	}
}
else{
	echo "something wrong!";
}

?>
<h2>Contacts us</h2>
<div id="maps">
			<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1915.1572459859676!2d80.3228043!3d16.2556444!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a4a76e740000001%3A0xc41c8498715c6da0!2sR.V.R.+%26+J.C.College+of+Engineering!5e0!3m2!1sen!2sin!4v1552991848114" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>
<h2>we value your feedback!</h2>
			<form action="" method="post">
			<ul>
				
		
						<li>Name:<br>
						<input type="text" name="name" onkeypress="return onlyAlphabets(event,this);"  required placeholder="Your name here...">
						</li>
						
						<li>Email:<br>
						<input type="text" name="email" required placeholder="example@mail.com">
						</li>
						<li>Feedback:<br>
						<textarea rows="10" cols="28" name="text"> 
					    </textarea>
						</li>
						<input type="submit" value="submit"/>
				
						
			<ul>
			</form>
<?php include 'includes/overall/footer.php';?>