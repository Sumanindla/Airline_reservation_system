<div class="widget">
                <h2>Admin</h2>
                <div class="inner">
					<form action="admin.php" method="post">
				    <ul id="login">
					<li>
					<a href="admin.php">Admin Panel</a>
					</li>
					</ul>
				 
				 
				 
					</form>
					
                </div>
            </div>
			