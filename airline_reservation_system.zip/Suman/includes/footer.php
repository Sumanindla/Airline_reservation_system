 <footer>
			<p>
			Address:<br>RVR & JC College of Engineering, Chowdawaram, Chandramoulipuram,Guntur, AP 522019<br>
			Contact:7036054445<BR>
			</p>
        &copy; ANairlines All rights reserved. Developed by TEAM NO.20.
    </footer>